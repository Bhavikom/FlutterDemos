# Flutter Splash Demo

A Flutter applicaiton to showcase how to make different types of Splash Screens. In this demo we have used Video Player plugin, the plugin name is video_player 0.6.4

# Demo
<img height="480px" src="https://github.com/Aeologic/flutter_splash_app/blob/master/screens/flutter_splash_demo.gif">



# Android Screen
<img height="480px" src="https://github.com/Aeologic/flutter_splash_app/blob/master/screens/Android1.jpg">


# iOS Screen
<img height="480px" src="https://github.com/Aeologic/flutter_splash_app/blob/master/screens/iPhone1.jpg">


## Getting Started

For help getting started with Flutter, view our online
[documentation](https://flutter.io/).

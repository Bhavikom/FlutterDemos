 String HOME_SCREEN='/HomeScreen',IMAGE_SPLASH='/ImageSplashScreen',VIDEO_SPALSH='/VideoSplashScreen',
     ANIMATED_SPALSH='/AnimatedSplashScreen';